
using UnityEngine;

public class OSManager : MonoBehaviour
{
    [Header("Window Configuration")]
    [SerializeField] private Transform windowLayer;

    public void OpenWindow(OSWindow window)
    {
        if (window == null)
        {
            Debug.LogWarning("[OS] Cannot open a null window.");
            return;
        }

        window.Open();
        FocusWindow(window);
    }

    public void CloseWindow(OSWindow window)
    {
        if (window == null) return;

        window.Close();
    }

    public void FocusWindow(OSWindow window)
    {
        if (window == null) return;

        Transform target = window.transform;

        if (windowLayer != null && target.parent == windowLayer)
        {
            target.SetAsLastSibling();
        }
        else
        {
            target.SetAsLastSibling();
        }
    }
}
